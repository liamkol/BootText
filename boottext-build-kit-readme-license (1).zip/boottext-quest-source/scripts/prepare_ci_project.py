#!/usr/bin/env python3
"""Materialize BootText inside the official Quest mod template for CI builds."""
from __future__ import annotations
import argparse
import json
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--template-dir', required=True, type=Path,
                        help='Path to quest-mod-template/template')
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--ndk-path', required=True,
                        help='Absolute Android NDK path to write to ndkpath.txt')
    args = parser.parse_args()

    template = args.template_dir.resolve()
    output = args.output_dir.resolve()
    if not (template / 'CMakeLists.txt').is_file() or not (template / 'cmake').is_dir():
        parser.error(f'{template} does not look like the official Quest mod template/template directory')
    if output.exists() and any(output.iterdir()):
        parser.error(f'output directory must be empty: {output}')
    output.mkdir(parents=True, exist_ok=True)
    shutil.copytree(template, output, dirs_exist_ok=True)

    replacements = {
        '#{ndkpath}': args.ndk_path.replace('\\', '/'),
        '#{id}': 'boottext',
        '#{name}': 'BootText',
        '#{author}': 'Liam',
        '#{description}': 'Displays a random custom greeting briefly when the main menu opens.',
    }
    for file in output.rglob('*'):
        if not file.is_file():
            continue
        try:
            text = file.read_text(encoding='utf-8')
        except (UnicodeDecodeError, OSError):
            continue
        changed = text
        for token, value in replacements.items():
            changed = changed.replace(token, value)
        if changed != text:
            file.write_text(changed, encoding='utf-8', newline='\n')

    source_root = Path(__file__).resolve().parent.parent
    for relative in ('src/main.cpp', 'include/main.hpp', 'qpm.json', 'mod.template.json'):
        shutil.copy2(source_root / relative, output / relative)
    (output / 'scripts').mkdir(exist_ok=True)
    shutil.copy2(source_root / 'scripts/pack_qmod.py', output / 'scripts/pack_qmod.py')

    # Avoid pinning a machine-local NDK path in the checked-in source. This is a CI-only build tree.
    (output / 'ndkpath.txt').write_text(args.ndk_path.replace('\\', '/') + '\n', encoding='utf-8')
    with (output / 'qpm.json').open(encoding='utf-8') as f:
        qpm = json.load(f)
    if qpm['info']['id'] != 'boottext' or qpm['info']['additionalData']['overrideSoName'] != 'libboottext.so':
        raise SystemExit('QPM project metadata mismatch after preparation')
    print(f'Prepared BootText project at {output}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
