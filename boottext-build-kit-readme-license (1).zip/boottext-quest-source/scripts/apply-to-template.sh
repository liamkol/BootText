#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/generated/BootText-project" >&2
  exit 2
fi
TARGET="$(cd "$1" && pwd)"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -f "$TARGET/CMakeLists.txt" || ! -d "$TARGET/cmake" ]]; then
  echo "Target does not look like a generated Quest mod project (expected CMakeLists.txt and cmake/)." >&2
  exit 1
fi
mkdir -p "$TARGET/src" "$TARGET/include" "$TARGET/scripts"
cp "$ROOT/src/main.cpp" "$TARGET/src/main.cpp"
cp "$ROOT/include/main.hpp" "$TARGET/include/main.hpp"
cp "$ROOT/qpm.json" "$TARGET/qpm.json"
cp "$ROOT/mod.template.json" "$TARGET/mod.template.json"
cp "$ROOT/scripts/pack_qmod.py" "$TARGET/scripts/pack_qmod.py"

echo "BootText source applied to: $TARGET"
echo "Next: qpm-rust restore; qpm s build; python3 scripts/pack_qmod.py build/libboottext.so"
