#!/usr/bin/env python3
"""Package a compiled BootText Quest ARM64 library into a structurally checked QMOD."""
from __future__ import annotations

import argparse
import json
import struct
import sys
import zipfile
from pathlib import Path

MOD = {
    "$schema": "https://raw.githubusercontent.com/Lauriethefish/QuestPatcher.QMod/main/QuestPatcher.QMod/Resources/qmod.schema.json",
    "_QPVersion": "1.2.0",
    "name": "BootText",
    "id": "boottext",
    "author": "Liam",
    "version": "0.1.0",
    "packageId": "com.beatgames.beatsaber",
    "packageVersion": "1.40.8_7379",
    "modloader": "Scotland2",
    "description": "Displays a random custom greeting briefly when the main menu opens.",
    "dependencies": [
        {"id": "bsml", "versionRange": "^0.4.55", "downloadIfNeeded": True},
        {"id": "custom-types", "versionRange": "^0.18.3", "downloadIfNeeded": True},
    ],
    "modFiles": ["libboottext.so"],
    "libraryFiles": [],
    "fileCopies": [],
}


def is_aarch64_elf(path: Path) -> bool:
    with path.open("rb") as f:
        header = f.read(20)
    # ELF magic, 64-bit class, little-endian, e_machine = EM_AARCH64 (183).
    return (
        len(header) >= 20
        and header[:4] == b"\x7fELF"
        and header[4] == 2
        and header[5] == 1
        and struct.unpack("<H", header[18:20])[0] == 183
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("library", type=Path, help="path to compiled libboottext.so")
    parser.add_argument("-o", "--output", type=Path, default=Path("BootText.qmod"))
    args = parser.parse_args()

    lib = args.library.resolve()
    out = args.output.resolve()
    if not lib.is_file():
        parser.error(f"compiled library not found: {lib}")
    if not is_aarch64_elf(lib):
        parser.error("library is not an ELF64 little-endian AArch64 (Quest ARM64) binary")
    if lib.name != "libboottext.so":
        print(f"Note: storing {lib.name} in the QMOD as libboottext.so", file=sys.stderr)

    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=False) as zf:
        zf.writestr("mod.json", json.dumps(MOD, indent=2, ensure_ascii=False) + "\n")
        zf.write(lib, "libboottext.so")

    with zipfile.ZipFile(out, "r") as zf:
        bad = zf.testzip()
        entries = zf.namelist()
        if bad:
            out.unlink(missing_ok=True)
            raise RuntimeError(f"ZIP CRC validation failed for {bad}")
        if entries.count("mod.json") != 1 or "libboottext.so" not in entries:
            out.unlink(missing_ok=True)
            raise RuntimeError("QMOD is missing its root mod.json or declared native library")
        parsed = json.loads(zf.read("mod.json"))
        if parsed.get("packageVersion") != "1.40.8_7379" or parsed.get("packageId") != "com.beatgames.beatsaber":
            out.unlink(missing_ok=True)
            raise RuntimeError("metadata target mismatch")

    print(f"Created: {out}")
    print("Validated: ZIP CRC, root mod.json, Beat Saber 1.40.8_7379 metadata, ELF64 AArch64 library.")
    print("Not verified: runtime compatibility or in-headset behavior; test on a backup/modded install first.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
