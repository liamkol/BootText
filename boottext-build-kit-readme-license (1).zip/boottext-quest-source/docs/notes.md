# Implementation notes

- The hook targets `MainMenuViewController::DidActivate` using the standard Quest `beatsaber-hook` pattern.
- The temporary UI container is owned by BootText; its timed destruction should only remove this mod's UI.
- BSML's Quest documentation lists `custom-types` as a prerequisite even for simple UI integrations, so it is declared in QPM and QMOD metadata.
- `.github/workflows/build-qmod.yml` builds on a GitHub-hosted runner because this authoring runtime does not have the Android NDK/QPM installed and cannot reach GitHub from its shell.
- A successful CI compile and structural QMOD validation would still need in-headset testing before calling it verified working.
