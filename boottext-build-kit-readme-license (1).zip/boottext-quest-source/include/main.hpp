#pragma once

#include "scotland2/shared/modloader.h"
#include "beatsaber-hook/shared/utils/hooking.hpp"
#include "beatsaber-hook/shared/utils/il2cpp-functions.hpp"
#include "beatsaber-hook/shared/utils/utils.h"
#include "paper/shared/logger.hpp"

constexpr auto BootTextLogger = Paper::ConstLoggerContext("BootText");
