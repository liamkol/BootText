# Third-Party Notices

BootText's original source code and documentation are offered under the MIT
License in [`LICENSE`](LICENSE). That license applies only to BootText-authored
material; it does not replace the terms of third-party tools, dependencies, or
template material.

## Quest mod template

The GitHub Actions workflow downloads
[Lauriethefish/quest-mod-template](https://github.com/Lauriethefish/quest-mod-template)
at build time. Its repository identifies its license as the
[Unlicense](https://github.com/Lauriethefish/quest-mod-template/blob/main/LICENSE)
and credits Lauriethefish, danrouse, and Bobby Shmurner. The upstream template
is fetched during the build; its full source tree is not vendored in this
repository. Review the upstream repository for its current contents and terms.

## QPM dependencies

The following packages are declared in [`qpm.json`](qpm.json) and are restored
by QPM during the build rather than vendored in this source archive:

- `beatsaber-hook`
- `scotland2`
- `paper`
- `bsml`
- `custom-types`

Each dependency remains under the license and notices supplied by its own
upstream project/package. The exact artifacts resolved by QPM can change with
package repository updates and version-range resolution. Before redistributing
a built binary or bundled dependencies, record the resolved package versions,
review the corresponding upstream licenses, and include any notices required
by those terms. The dependency list above is not a claim that those projects
share BootText's MIT license.

## Build tools and services

The automated workflow also uses third-party tools and GitHub Actions, including
QPM CLI, the Android SDK/NDK, CMake, Ninja, `actions/checkout`,
`android-actions/setup-android`, `dtolnay/rust-toolchain`, and
`actions/upload-artifact`. These tools are not bundled with BootText and remain
subject to their own licenses and service terms.

## Trademarks

Beat Saber, Meta Quest, and related marks belong to their respective owners.
BootText is an independent fan-made project and is not affiliated with or
endorsed by Beat Games, Meta, or the maintainers of the third-party libraries
listed above.
