#include "main.hpp"

#include "GlobalNamespace/MainMenuViewController.hpp"
#include "UnityEngine/GameObject.hpp"
#include "UnityEngine/Object.hpp"
#include "UnityEngine/Transform.hpp"
#include "bsml/shared/BSML.hpp"

#include <array>
#include <cstddef>
#include <cstdlib>
#include <ctime>

static modloader::ModInfo modInfo{MOD_ID, VERSION, 0};
static bool messageShownThisLaunch = false;

// Change these strings to personalize the greeting pool.
static constexpr std::array<const char*, 4> kGreetings = {
    "Welcome back, nerd.",
    "PJO CLAN - ready?",
    "Time to chase another leaderboard.",
    "Quest 2 is still fighting for its life."
};

MAKE_HOOK_MATCH(
    MainMenuViewController_DidActivate,
    &GlobalNamespace::MainMenuViewController::DidActivate,
    void,
    GlobalNamespace::MainMenuViewController* self,
    bool firstActivation,
    bool addedToHierarchy,
    bool screenSystemEnabling
) {
    MainMenuViewController_DidActivate(self, firstActivation, addedToHierarchy, screenSystemEnabling);

    // Only show this once after a fresh game launch, not every time the player
    // returns to the main menu from a song.
    if (messageShownThisLaunch || !addedToHierarchy) return;
    messageShownThisLaunch = true;

    const char* message = kGreetings[static_cast<std::size_t>(std::rand()) % kGreetings.size()];

    // Give the message its own temporary container so cleanup removes only our
    // UI and doesn't touch any of Beat Saber's existing menu objects.
    auto* root = UnityEngine::GameObject::New_ctor(il2cpp_utils::createcsstr("BootTextTemporaryRoot"));
    if (!root) {
        BootTextLogger.error("Failed to create startup-message container");
        return;
    }

    root->get_transform()->SetParent(self->get_transform(), false);
    BSML::Lite::CreateText(root->get_transform(), message);
    UnityEngine::Object::Destroy(root, 5.0f);

    BootTextLogger.info("Displayed startup greeting: %s", message);
}

MOD_EXTERN_FUNC void setup(CModInfo* info) noexcept {
    *info = modInfo.to_c();
    Paper::Logger::RegisterFileContextId(BootTextLogger.tag);
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
    BootTextLogger.info("BootText setup complete");
}

MOD_EXTERN_FUNC void late_load() noexcept {
    il2cpp_functions::Init();
    BSML::Init();
    INSTALL_HOOK(BootTextLogger, MainMenuViewController_DidActivate);
    BootTextLogger.info("BootText hook installed");
}
